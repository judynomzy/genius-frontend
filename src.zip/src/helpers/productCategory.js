const productCategory =[
  {id:1,label: "Journals", value:"journals"},
  {id:2,label: "Manuscripts", value:"manuscripts"},
  {id:3,label: "Projects", value:"projects"},
  {id:4,label: "Training Courses", value:"training courses"}
]
export default productCategory